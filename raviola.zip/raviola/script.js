// La Ravi'ola : petites interactions. Le site reste lisible et utilisable sans JavaScript.
(function () {
  var doc = document.documentElement;
  doc.classList.remove('no-js'); doc.classList.add('js');

  // 1. Menu mobile
  var burger = document.querySelector('.burger'), nav = document.getElementById('menu');
  if (burger && nav) {
    burger.addEventListener('click', function () {
      var ouvert = burger.getAttribute('aria-expanded') === 'true';
      burger.setAttribute('aria-expanded', String(!ouvert));
      nav.classList.toggle('ouvert', !ouvert);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && nav.classList.contains('ouvert')) { burger.click(); burger.focus(); }
    });
  }


  // =====================================================================
  //  RÉGLAGES : liens des tableurs Google de la pizzeria (format CSV)
  //  Fichier > Partager > Publier sur le Web > choisir l'onglet > CSV
  //  Laisser vide : le site affiche les infos écrites dans les pages.
  // =====================================================================
  var TABLEUR_INFOS = '';   // onglet "infos" : annonce, saison, horaires
  var TABLEUR_CARTE = '';   // onglet "carte" : pizzas et à-côtés

  var JOURS = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };

  function lireCSV(txt) {
    var lignes = [], ligne = [], champ = '', guil = false;
    for (var i = 0; i < txt.length; i++) {
      var c = txt[i];
      if (guil) { if (c === '"' && txt[i + 1] === '"') { champ += '"'; i++; } else if (c === '"') guil = false; else champ += c; }
      else if (c === '"') guil = true;
      else if (c === ',') { ligne.push(champ); champ = ''; }
      else if (c === '\n' || c === '\r') { if (c === '\r' && txt[i + 1] === '\n') i++; ligne.push(champ); lignes.push(ligne); ligne = []; champ = ''; }
      else champ += c;
    }
    if (champ || ligne.length) { ligne.push(champ); lignes.push(ligne); }
    return lignes;
  }
  function charger(url) {
    if (!url || !window.fetch) return Promise.resolve(null);
    var sep = url.indexOf('?') > -1 ? '&' : '?';
    return fetch(url + sep + 't=' + Date.now(), { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.text() : null; })
      .then(function (t) { return t ? lireCSV(t) : null; })
      .catch(function () { return null; });
  }

  // ---------- Horaires : lus dans les tableaux de la page, remplaçables par le tableur ----------
  // Une plage s'écrit "18 h à 21 h" ou "11 h 30 à 13 h 30" ; plusieurs plages séparées par "et".
  function plages(texte) {
    var res = [], re = /(\d{1,2})\s*h\s*(\d{2})?\s*(?:à|-|a)\s*(\d{1,2})\s*h\s*(\d{2})?/gi, m;
    while ((m = re.exec(texte || ''))) res.push([+m[1] + (+(m[2] || 0)) / 60, +m[3] + (+(m[4] || 0)) / 60]);
    return res;
  }
  function heure(h) { var hh = Math.floor(h), mm = Math.round((h - hh) * 60); return hh + ' h' + (mm ? ' ' + (mm < 10 ? '0' : '') + mm : ''); }
  var HORAIRES = { hiver: {}, ete: {} }, saisonActuelle = 'hiver';
  document.querySelectorAll('[data-table]').forEach(function (bloc) {
    var s = bloc.getAttribute('data-table');
    bloc.querySelectorAll('tr[data-jour]').forEach(function (tr) { HORAIRES[s][tr.getAttribute('data-jour')] = tr.querySelector('td').textContent.trim(); });
  });
  if (!Object.keys(HORAIRES.hiver).length) { [4, 5, 6, 0].forEach(function (j) { HORAIRES.hiver[j] = '18 h à 21 h'; }); [1, 2, 3].forEach(function (j) { HORAIRES.hiver[j] = 'Fermé'; }); }

  function maintenantParis() {
    try {
      var p = new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/Paris', weekday: 'short', hour: 'numeric', minute: 'numeric', hourCycle: 'h23' }).formatToParts(new Date());
      var o = {}; p.forEach(function (x) { o[x.type] = x.value; });
      return { jour: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(o.weekday), h: +o.hour + (+o.minute) / 60 };
    } catch (e) { var d = new Date(); return { jour: d.getDay(), h: d.getHours() + d.getMinutes() / 60 }; }
  }
  var T = maintenantParis();

  function majStatut() {
    var H = HORAIRES[saisonActuelle], texte = '', classe = 'statut-ferme', auj = plages(H[T.jour]);
    for (var k = 0; k < auj.length; k++) if (T.h >= auj[k][0] && T.h < auj[k][1]) { texte = 'Ouvert maintenant, jusqu’à ' + heure(auj[k][1]); classe = 'statut-ouvert'; }
    if (!texte) for (k = 0; k < auj.length; k++) if (T.h < auj[k][0]) { texte = 'Fermé pour l’instant, ouvre aujourd’hui à ' + heure(auj[k][0]); break; }
    if (!texte) for (var i = 1; i <= 7; i++) { var j = (T.jour + i) % 7, pl = plages(H[j]); if (pl.length) { texte = 'Fermé, ouvre ' + (i === 1 ? 'demain' : JOURS[j]) + ' à ' + heure(pl[0][0]); break; } }
    if (!texte) texte = 'Appelez-nous pour connaître nos horaires';
    var nomSaison = saisonActuelle === 'ete' ? 'horaires d’été' : 'horaires d’hiver';
    document.querySelectorAll('[data-statut]').forEach(function (el) { el.innerHTML = '<span class="' + classe + '">' + texte + '</span> <small>(' + nomSaison + ')</small>'; });
  }
  function majTableaux() {
    ['hiver', 'ete'].forEach(function (s) {
      document.querySelectorAll('[data-table="' + s + '"] tr[data-jour]').forEach(function (tr) {
        var v = HORAIRES[s][tr.getAttribute('data-jour')]; if (v == null) return;
        var td = tr.querySelector('td'); td.textContent = v; td.classList.toggle('ferme', !plages(v).length);
      });
    });
    document.querySelectorAll('.horaires tr.aujourdhui').forEach(function (tr) { tr.classList.remove('aujourdhui'); var s = tr.querySelector('th small'); if (s) s.remove(); });
    document.querySelectorAll('.horaires tr[data-jour="' + T.jour + '"]').forEach(function (tr) {
      tr.classList.add('aujourdhui'); tr.querySelector('th').insertAdjacentHTML('beforeend', ' <small>(aujourd’hui)</small>');
    });
  }

  // Bascule hiver / été
  var bSaisons = document.querySelectorAll('[data-saison]');
  function voirSaison(s) {
    bSaisons.forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-saison') === s)); });
    document.querySelectorAll('[data-table]').forEach(function (d) { d.hidden = d.getAttribute('data-table') !== s; });
  }
  bSaisons.forEach(function (b) { b.addEventListener('click', function () { voirSaison(b.getAttribute('data-saison')); }); });
  if (bSaisons.length) voirSaison(saisonActuelle);
  majTableaux(); majStatut();

  // ---------- Bandeau d'annonce ----------
  function afficherAnnonce(texte) {
    var ancien = document.querySelector('.annonce'); if (ancien) ancien.remove();
    if (!texte) return;
    var d = document.createElement('div'); d.className = 'annonce'; d.setAttribute('role', 'status'); d.textContent = texte;
    var top = document.querySelector('.top'); if (top && top.parentNode) top.parentNode.insertBefore(d, top.nextSibling);
  }
  window.ravAfficherAnnonce = afficherAnnonce;

  // ---------- Carte : filtres (délégation, fonctionne aussi après mise à jour par le tableur) ----------
  var compteur = document.querySelector('[data-compteur]');
  function appliquerFiltre(f) {
    var n = 0;
    document.querySelectorAll('[data-filtre]').forEach(function (x) { x.setAttribute('aria-pressed', String(x.getAttribute('data-filtre') === f)); });
    document.querySelectorAll('[data-plats] .plat').forEach(function (p) {
      var ok = f === 'tout' || (' ' + p.getAttribute('data-tags') + ' ').indexOf(' ' + f + ' ') > -1;
      p.classList.toggle('cache', !ok); p.classList.remove('entre');
      if (ok) { n++; void p.offsetWidth; p.classList.add('entre'); }
    });
    if (compteur) compteur.textContent = n + (n > 1 ? ' pizzas' : ' pizza');
  }
  document.addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('[data-filtre]'); if (b) appliquerFiltre(b.getAttribute('data-filtre')); });

  function prix(p) { p = String(p || '').trim(); if (!p) return ''; var n = p.replace(',', '.'); if (/^\d+(\.\d+)?$/.test(n)) return (+n).toFixed(2).replace('.', ',') + ' €'; return /€/.test(p) ? p : p + ' €'; }
  function htmlPlat(r) {
    var tags = (r.tags || '').toLowerCase().split(/[\s,;]+/).filter(Boolean), base = (r.base || '').toLowerCase().indexOf('cr') === 0 ? 'creme' : (r.base ? 'tomate' : '');
    var badges = (tags.indexOf('sansviande') > -1 ? '<span class="badge">Sans viande ni poisson</span>' : '') + (tags.indexOf('local') > -1 ? '<span class="badge badge-local">Produit local</span>' : '') + (tags.indexOf('sucree') > -1 ? '<span class="badge">Sucrée</span>' : '');
    var ing = r.ingredients ? esc(r.ingredients).replace(/\.?$/, '.') : '';
    var apres = r.apres_cuisson ? ' <span class="apres">Après cuisson : ' + esc(r.apres_cuisson) + '</span>' : '';
    return '<article class="plat" data-tags="' + esc([base].concat(tags).join(' ').trim()) + '"><div class="plat-tete"><h3>' + esc(r.nom) + '</h3><span class="prix">' + esc(prix(r.prix)) + '</span></div>' +
      (ing || apres ? '<p>' + ing + apres + '</p>' : '') + (r.note ? '<p class="note">' + esc(r.note) + '</p>' : '') + '<div class="badges">' + badges + '</div></article>';
  }
  function majCarte(lignes) {
    if (!lignes || lignes.length < 2) return;
    var ent = lignes[0].map(function (h) { return h.trim().toLowerCase().replace(/[\s-]+/g, '_').replace('é', 'e').replace('è', 'e').replace('à', 'a'); });
    var rows = lignes.slice(1).map(function (l) { var o = {}; ent.forEach(function (h, i) { o[h] = (l[i] || '').trim(); }); return o; })
      .filter(function (o) { return o.nom && !/^(non|no|0|cach)/i.test(o.visible || 'oui'); });
    var pizzas = rows.filter(function (o) { return !o.categorie || /^pizza/i.test(o.categorie); });
    var cote = rows.filter(function (o) { return /^(a.?cote|cote|dessert|boisson|entree|accomp)/i.test(o.categorie || ''); });
    var zp = document.querySelector('[data-plats]'), zc = document.querySelector('[data-cote]');
    if (zp && pizzas.length) { zp.innerHTML = pizzas.map(htmlPlat).join(''); appliquerFiltre('tout'); }
    if (zc && cote.length) zc.innerHTML = cote.map(htmlPlat).join('');
    document.querySelectorAll('[data-nb-pizzas]').forEach(function (el) { el.textContent = pizzas.length; if (el.hasAttribute('data-compte')) el.setAttribute('data-compte', pizzas.length); });
  }

  // ---------- Lecture des tableurs ----------
  charger(TABLEUR_INFOS).then(function (lignes) {
    if (!lignes) return;
    var d = {};
    lignes.forEach(function (l) { if (l[0]) d[l[0].trim().toLowerCase().replace('é', 'e')] = (l[1] || '').trim(); });
    afficherAnnonce(d.annonce);
    if (d.saison) { saisonActuelle = /^e/i.test(d.saison.replace('é', 'e')) ? 'ete' : 'hiver'; }
    ['hiver', 'ete'].forEach(function (s) { JOURS.forEach(function (nom, j) { if (d[s + '_' + nom] != null && d[s + '_' + nom] !== '') HORAIRES[s][j] = d[s + '_' + nom]; }); });
    majTableaux(); majStatut(); if (bSaisons.length) voirSaison(saisonActuelle);
  });
  charger(TABLEUR_CARTE).then(majCarte);

  // 4. Apparition douce au défilement
  var aAnimer = document.querySelectorAll('.apparait, h2');
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('vu'); io.unobserve(e.target); } }); }, { threshold: .12 });
    aAnimer.forEach(function (el) { io.observe(el); });
  } else { aAnimer.forEach(function (el) { el.classList.add('vu'); }); }

  // ---------- Animations v2 ----------
  var calme = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // En-tête compact (écoute passive + requestAnimationFrame)
  var top = document.querySelector('.top'), enAttente = false;
  function majTop() { enAttente = false; if (top) top.classList.toggle('compact', window.scrollY > 40); }
  window.addEventListener('scroll', function () { if (!enAttente) { enAttente = true; requestAnimationFrame(majTop); } }, { passive: true });
  majTop();

  // Effet magnétique (souris uniquement)
  if (!calme && window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
    document.querySelectorAll('.btn').forEach(function (b) {
      var raf = 0, x = 0, y = 0;
      b.addEventListener('pointermove', function (e) {
        var r = b.getBoundingClientRect();
        x = (e.clientX - r.left - r.width / 2) * 0.25;
        y = (e.clientY - r.top - r.height / 2) * 0.35;
        if (!raf) raf = requestAnimationFrame(function () {
          raf = 0; b.classList.add('aimante');
          b.style.setProperty('--mx', Math.max(-10, Math.min(10, x)).toFixed(1) + 'px');
          b.style.setProperty('--my', Math.max(-8, Math.min(8, y)).toFixed(1) + 'px');
        });
      });
      b.addEventListener('pointerleave', function () {
        if (raf) { cancelAnimationFrame(raf); raf = 0; }
        b.classList.remove('aimante'); b.style.setProperty('--mx', '0px'); b.style.setProperty('--my', '0px');
      });
    });
  }

  // Chiffres qui défilent quand ils apparaissent
  var chiffres = document.querySelectorAll('[data-compte]');
  if (!calme && 'IntersectionObserver' in window) {
    chiffres.forEach(function (el) { el.textContent = el.getAttribute('data-depart') || '0'; });
    var ioC = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting) return;
        ioC.unobserve(e.target);
        var el = e.target, fin = +el.getAttribute('data-compte'), dep = +(el.getAttribute('data-depart') || 0);
        var duree = 1400, t0 = performance.now();
        (function pas(t) {
          var k = Math.min(1, (t - t0) / duree), v = 1 - Math.pow(1 - k, 3);
          el.textContent = Math.round(dep + (fin - dep) * v);
          if (k < 1) requestAnimationFrame(pas);
        })(t0);
      });
    }, { threshold: .5 });
    chiffres.forEach(function (el) { ioC.observe(el); });
  }
})();


// ---------- Navigation entre les rubriques de index.html ----------
(function () {
  if (!document.querySelector('[data-vue]')) return;
  var courant = null;
  function montre() {
    var id = courant || (location.hash || '#index').slice(1);
    if (!document.querySelector('[data-vue="' + id + '"]')) id = 'index';
    document.querySelectorAll('[data-vue]').forEach(function (v) { v.hidden = v.getAttribute('data-vue') !== id; });
    document.querySelectorAll('#menu a').forEach(function (a) { if (a.getAttribute('href') === '#' + id) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
    var n = document.getElementById('menu'), b = document.querySelector('.burger'); if (n && n.classList.contains('ouvert') && b) b.click();
    try { window.scrollTo(0, 0); } catch (x) {}
    document.querySelectorAll('[data-vue="' + id + '"] .apparait, [data-vue="' + id + '"] h2').forEach(function (el) { requestAnimationFrame(function () { el.classList.add('vu'); }); });
  }
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[href^="#"]'); if (!a) return;
    var id = a.getAttribute('href').slice(1); if (!document.querySelector('[data-vue="' + id + '"]')) return;
    e.preventDefault(); courant = id; try { history.replaceState(null, '', '#' + id); } catch (x) {} montre();
  });
  window.addEventListener('hashchange', function () { courant = null; montre(); });
  montre();
})();

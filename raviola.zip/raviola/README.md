# Site de la pizzeria La Ravi'ola (Ravilloles, Jura)

Version du 2 novembre 2026. Site statique : HTML, CSS et JavaScript, sans framework ni dépendance.

## Contenu du dossier

| Fichier | Rôle |
| --- | --- |
| `index.html` | Le site : accueil, carte, la pizzeria, horaires et accès (rubriques affichées par le menu) |
| `mentions-legales.html` | Mentions légales (champs `[À FOURNIR]` à compléter) |
| `confidentialite.html` | Politique de confidentialité |
| `style.css` | Mise en forme, animations, police Fraunces intégrée (licence SIL OFL 1.1) |
| `script.js` | Menu mobile, filtres de la carte, horaires hiver/été, « ouvert maintenant », animations, lecture du tableur Google |
| `images/` | Photo de la salle (WebP) |

## Voir le site

Double-cliquer sur `index.html`. Tout fonctionne hors ligne, sauf la lecture du tableur Google, qui demande que le site soit hébergé.

## Rendre le site modifiable par la gérante (tableur Google)

1. Créer un tableur Google au nom de la gérante avec deux onglets, `infos` et `carte`, à partir des modèles ci-dessous (Fichier > Importer).
2. Publier chaque onglet : Fichier > Partager > Publier sur le Web > l'onglet > format CSV. Copier les deux liens.
3. Dans `script.js`, en haut du fichier, coller les liens :

```js
var TABLEUR_INFOS = 'lien CSV de l'onglet infos';
var TABLEUR_CARTE = 'lien CSV de l'onglet carte';
```

Si un lien est vide ou que le tableur ne répond pas, le site affiche les informations écrites dans `index.html`.

Ce que la gérante peut changer : le bandeau d'annonce (`annonce`, vide = pas de bandeau), la saison (`hiver` ou `ete`), les horaires de chaque jour, les pizzas et à-côtés (prix, ingrédients, `visible` = `non` pour masquer).

Testé avec des fichiers CSV servis en local. Pas encore testé avec un vrai tableur Google publié.

### Modèle de l'onglet `infos`

```csv
cle,valeur,aide (ne pas modifier la colonne A)
annonce,,"Message en haut du site. Ex : Fermé ce soir, désolées ! Laisser vide = pas de message."
saison,hiver,hiver ou ete : quels horaires sont en vigueur maintenant
hiver_lundi,Fermé,"Écrire ""Fermé"" ou ""18 h à 21 h"" (plusieurs plages : ""11 h 30 à 13 h 30 et 18 h à 21 h"")"
hiver_mardi,Fermé,
hiver_mercredi,Fermé,
hiver_jeudi,18 h à 21 h,
hiver_vendredi,18 h à 21 h,
hiver_samedi,18 h à 21 h,
hiver_dimanche,18 h à 21 h,
ete_lundi,Fermé,
ete_mardi,Fermé,
ete_mercredi,18 h à 21 h,
ete_jeudi,11 h 30 à 13 h 30,
ete_vendredi,18 h à 21 h,
ete_samedi,18 h à 21 h,
ete_dimanche,18 h à 21 h,
```

### Modèle de l'onglet `carte`

```csv
categorie,nom,prix,ingredients,apres_cuisson,base,tags,note,visible
pizza,Margherita,"10,50","Tomate, mozzarella, olives",,tomate,sansviande,La plus simple de la carte.,oui
pizza,Régina,"13,00","Tomate, mozzarella, jambon blanc, champignons frais, olives",,tomate,,,oui
pizza,Biquette,"14,50","Crème, mozzarella, chèvre, tomates cerises","miel, noix, roquette",crème,sansviande local,"Le miel vient de La danse des abeilles, à Ravilloles.",oui
pizza,4 Fromages,"14,00","Tomate, mozzarella, chèvre, gorgonzola, raclette",,tomate,sansviande,,oui
pizza,Provençale,"13,00","Tomate, poivrons, tomates cerises, pesto maison, œufs bio",,tomate,sansviande,Avec le pesto maison.,oui
pizza,Truffa,"15,50","Crème, crème de truffe noire, mozzarella, jambon blanc, champignons frais",roquette,crème,,,oui
pizza,Parma,"15,00","Tomate, mozzarella","jambon de Parme, parmigiano, roquette",tomate,,Le jambon de Parme est posé après cuisson.,oui
pizza,Rivière,"15,50","Crème, mozzarella, truite","truite, roquette",crème,,La truite est mise deux fois : avant et après cuisson.,oui
pizza,Bella,"14,00","Tomate, mozzarella, oignons, poivrons, pancetta, tomates cerises",,tomate,,,oui
pizza,Raclette,"14,90","Crème, pomme de terre, fromage à raclette, jambon blanc",poivre du moulin,crème,,,oui
pizza,Merguez,"14,00","Tomate, oignons rouges, poivrons, émincé de merguez du boucher, mozzarella",,tomate,local,Merguez du boucher.,oui
pizza,Napoli,"14,00","Sauce tomate, mozzarella, olives noires","anchois à l'huile, câpres",tomate,,,oui
pizza,Barbie,"9,00","Crème, pralines roses",,crème,sucree sansviande,La pizza sucrée.,oui
a cote,Salade d'accompagnement,"3,50","Salade, tomates cerises, oignons rouges",,,,,oui
a cote,Plateau charcuterie,"9,00 € / pers.","Minimum 2 personnes. Sur commande, 48 h à l'avance",,,,,oui
a cote,Desserts maison,"4,50",,,,,,oui
a cote,Glaces artisanales,"4,50",Pot de 100 ml,,,,,oui
a cote,Boissons,"2,00",,,,,,oui
```

## Mise en ligne

1. Héberger le dossier chez un hébergeur de sites statiques (Netlify, Cloudflare Pages ou équivalent). Tarifs et conditions à vérifier.
2. Brancher un nom de domaine acheté au nom de la gérante.
3. Remplacer `domaine-a-definir.fr` par le vrai domaine dans `index.html` (balise canonical et données structurées).
4. Compléter les `[À FOURNIR]` de `mentions-legales.html` et `confidentialite.html`.
5. Tester sur un vrai téléphone : bouton d'appel, menu, filtres, bandeau.

## Reste à fournir

- Date de la carte.
- Horaires d'été : le jeudi, seulement le midi ?
- Accès en fauteuil roulant.
- Mentions légales : raison sociale, forme juridique, SIREN, directeur de publication, hébergeur, prestataire.
- Photos dont la pizzeria détient les droits (la photo actuelle vient d'un site d'avis).
- Accord des auteurs des avis cités.
